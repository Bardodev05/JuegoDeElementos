const express = require("express")
const cors = require("cors")
const app = express()

app.use(cors())
app.use(express.json())

const jugadores = []

class Jugador {
    constructor(id) { 
        this.id = id 
    }
    asignarMascota(mascotas) { 
        this.mascotas = mascotas
    }

    actualizarPosicion(x, y){
        this.x = x
        this.y = y 
    }
}

class Mascota { 
    constructor(Nombre) { 
        this.Nombre = Nombre
    } 
}

app.get("/unirseAlJuego", (req, res) => {
    const id = `${Math.random()}`
    const jugador = new Jugador(id)

    jugadores.push(jugador)
    
    res.setHeader("Access-Control-Allow-Origin", "*")
    res.send(id)
});

app.post("/juego/:jugadorId", (req, res) => {
    const jugadorId = req.params.jugadorId || ""
    const nombreMascota = req.body.Nombre || ""
    const Nombre = new Mascota(nombreMascota);
    const jugadorIndex = jugadores.findIndex((jugador) => jugadorId === jugador.id)
   
    if (jugadorIndex >= 0) { 
        jugadores[jugadorIndex].asignarMascota(Nombre);
    }
   
    console.log(jugadores)
    console.log(jugadorId)
    res.end()
})

fetch(`http://localhost:8080/juego/${jugadorId}/posicion`, {
    method: "post",
    headers: {
        "Content-Type": "application/json"
    },
    body: JSON.stringify({
        x,
        y
    })
})
.then(function (res) {
    if (res.ok) {
        res.json()
        .then(function ({ enemigos }) {
            console.log(enemigos); 
            mascotaEnemigos.map(function (enemigo){
                let mascotaEnemigos = null
                const mascotaNombre = enemigo.Juego.nombre || ""
                
                if(mascotaNombre === hipodoge) {
                    mascotaEnemigos = new Juego("Hipodoge", "media/per.1.png", 5, "media/hipodoge.webp")
                }else if (mascotaNombre === capipepo){
                    mascotaEnemigos = new Juego("Capipepo", "media/per.2.png", 5, "media/capipepo.webp")
                }else if (mascotaNombre) {
                    mascotaEnemigos = new Juego("Ratigueya", "media/per.3.png", 5, "media/ratigueya.webp")
                }

                mascotaEnemigos.x = enemigo.x
                mascotaEnemigos.y = enemigo.y
               
                return mascotaEnemigos
            })
         });
    }
});


app.listen(8080, () => { 
    console.log("Servidor funcionando") 
});
